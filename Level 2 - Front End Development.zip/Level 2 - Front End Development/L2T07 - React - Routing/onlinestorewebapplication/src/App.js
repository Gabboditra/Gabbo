import React, { useState } from "react";
import { Routes, Route, Link, useLocation } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import Home from "./Components/Home";
import Products from "./Components/Products";
import About from "./Components/About";
import "./App.css";
import TotalPrice from "./Components/TotalPrice";

// Main App component that handles routing and global state
export default function App() {
  const [sum, setSum] = useState(0); // Total sum of all products bought
  const [showTotal, setShowTotal] = useState(false); // checks whether to show total
  const location = useLocation(); // get current path

  const showTotalOnPages = location.pathname !== "/"; // Don't show total on Home page

  return (
    <div className="App">
      <h1>Online Store Web Application</h1>

      {/* Navigation links */}
      <nav>
        <Link to="/">Home</Link>
        <br />
        <Link to="/Products">Products</Link>
        <br />
        <Link to="/About">About</Link>
      </nav>

      {/* Show total price component if available */}
      {showTotal && showTotalOnPages && (
        <div style={{ position: "absolute", top: 10, right: 10 }}>
          <TotalPrice sum={sum} />
        </div>
      )}

      {/* Route configuration */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route
          path="/Products"
          element={<Products setSum={setSum} setShowTotal={setShowTotal} />}
        />
        <Route path="/About" element={<About sum={sum} />} />
      </Routes>
    </div>
  );
}
