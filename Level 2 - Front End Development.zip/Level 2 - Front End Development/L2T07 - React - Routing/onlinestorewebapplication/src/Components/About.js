import React from "react";
import { Figure } from "react-bootstrap";
import storelogo from "../assets/storelogo.png";
import store1 from "../assets/store1.png";
import store2 from "../assets/store2.png";

// About component displaying the store´s info
export default function About() {
  return (
    <div className="p-4">
       {/* Store Title */}
      <h2>About Our Store</h2>

       {/* Store Logo */}
      <Figure>
        <Figure.Image width={171} height={180} alt="Logo" src={storelogo} />
        <Figure.Caption>
          We’re a modern lifestyle tech store offering hand-picked essentials
          for your daily life.
        </Figure.Caption>
      </Figure>

{/* Store Pictures */}
      <div className="d-flex gap-4">
        <Figure>
          <Figure.Image
            width={200}
            height={180}
            alt="Store Interior"
            src={store1}
          />
          <Figure.Caption>Our cozy shop.</Figure.Caption>
        </Figure>

        <Figure>
          <Figure.Image
            width={200}
            height={180}
            alt="Store Front"
            src={store2}
          />

{/* Address info */}
          <Figure.Caption>Visit us at Main Street 123.</Figure.Caption>
        </Figure>
      </div>

      {/* Contact details */}
      <div className="mt-4">
        <h5>Contact Us</h5>
        <p>Email: welcome@store.com</p>
        <p>Phone: (123) 456-7890</p>
      </div>
    </div>
  );
}
