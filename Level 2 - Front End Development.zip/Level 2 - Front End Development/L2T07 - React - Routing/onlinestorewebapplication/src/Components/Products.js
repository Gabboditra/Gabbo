import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import Dropdown from "react-bootstrap/Dropdown";

// Products Component displaying a list of products
export default function Products({ setSum, setShowTotal }) {
  const location = useLocation(); // get current path
  const navigate = useNavigate(); // Router hook for navigation
  const state = location.state; // access state passed via routing
  const name = state?.name; // get the name from state if exists

  // state to track selected colours for items
  const [selectedColors, setSelectedColors] = useState({});

   // Function to handle the 'Buy' button click, adds price to the total sum
  const handleBuy = (price) => {
    setSum((prevSum) => prevSum + price);
    setShowTotal(true);
  };

  // Function to handle color functionality, updates the selected color for each product
  const handleColorSelect = (title, color) => {
    setSelectedColors((prev) => ({
      ...prev,
      [title]: color,
    }));
  };

   // Array of items with details
  const items = [
    {
      title: "Wireless Keyboard",
      price: 10,
      description: "Keyboard with a sleek and portable design",
      image:
        "https://www.hp.com/de-de/shop/Html/Merch/Images/c07584948_1750x1285.jpg",
      colors: ["Black", "White", "Gray"],
    },

    {
      title: "Bluetooth Speaker",
      price: 100,
      description: "Powerful speaker with deep bass and 10-hour playtime",
      image:
        "https://de.jbl.com/dw/image/v2/BFND_PRD/on/demandware.static/-/Sites-masterCatalog_Harman/default/dw00f57470/JBL_CHARGE5_HERO_BLACK_0046_x1.png?sw=680&sh=680",
      colors: ["Orange", "Blue", "White"],
    },
    {
      title: "SmartFit Fitness Tracker",
      price: 50,
      description: "Tracks steps, sleep, heart rate, etc. ",
      image:
        "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRTNTA0qJ-tjqbqBPgfMOLI4Un6UfePV8Df5gxurM_xFDRR_bdpYqFiZLpFqwNmyy8QHnNAquFVyRupl7CeuQBIfZFOCrkNwMv69qvCRP3TmMtHsIz3IdXaNy8hhYN5z2TTaXtCbppf5w&usqp=CAc",
      colors: ["Purple", "Yellow", "Green"],
    },
    {
      title: "Travel Backpack",
      price: 70,
      description: "Water-resistant backpack for travels",
      image:
        "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcR-CDuumYFl0OI9BY98LJCfaYD0FhitVPEizr3Yteal84dwoM9xE3fecKKFDyEkj-cbTuXpEH13l4y3d8s4s1zCVxVXtVSHMm3LDaINIgSCg5Y7tR20nGoqChcy5iE5Kh2SyvKn6d_w58k&usqp=CAc",
      colors: ["Brown", "White", "Red"],
    },
    {
      title: "French Press",
      price: 10,
      description:
        "French press with a stainless steel filter for rich, bold coffee",
      image:
        "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRA1IKak3NvBg_nLDRUW4zbEshh3wOacH59OgMg-9rSyUKBnL0mfDdNkRC_71LGwoICjGFAMcNJOn6VsA5YbpFitlejdom_vpPb22-QQaxWgCbQ4Ry-scBGNBZNBHOgRjEQwVhd_R_LoCQ&usqp=CAc",
      colors: ["Blue", "Beige", "Gray"],
    },
    {
      title: "Toothbrush Set",
      price: 5,
      description: "A pack of biodegradable bamboo toothbrushes",
      image:
        "https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcQhXzjEF0u-VnfZBkgd7UmgTUzaUsb1ejciLzvexBPXhPJ60iAGhIViX4WW1hhNi7RhFFgbFErQVJppaF3cxOLKKivDmrBXShaH-KpCZG55buNSOsuN6zivwFOiW4ftZG6aZc11ZSsZ654&usqp=CAc",
      colors: ["Violet", "Pink", "Gray"],
    },
    {
      title: " Instant Camera",
      price: 85,
      description:
        "Retro-style camera that prints fun, wallet-sized photos instantly",
      image:
        "https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcTSFmFLIPao6iGUtJk1F2zOOgMJN1YnFPEoIo3E4BTmS8vQ9exElPjCpSqsQc1hJH-9Q93mUY1Ye44NzUAKGFZ5fMt2VaMnfDBpXxS7Pnab4aJ-3gBvfz9jCLhLvV9dYOKYarZgWw&usqp=CAc",
      colors: ["Black", "Green", "Gray"],
    },
    {
      title: "Screen Protector",
      price: 7,
      description:
        "anti-scratch, and fingerprint-resistant for ultimate phone protection",
      image:
        "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcT_Ll6dJTifctbQLAVNqxKOO_2S9y2f43kczh6HCIQm_7YhuaNbnnqOeE4Te_N8hYbhZzfeSt1PYz8kLFZDxGBWDtSY7OgUFbkuL3TPExNa_FDOnMoUPmI0RK3VTvnzQ2BwvosUlSerjg&usqp=CAc",
      colors: ["Orange", "Yellow", "Red"],
    },
    {
      title: "Resistance Bands",
      price: 25,
      description:
        "Set of 5 color-coded bands for strength training, yoga, or physical therapy",
      image:
        "https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcR-smQnqlunE7mj_43sPwYLRFKnUEK8meMRR8jYptzlW7Nt0U9hJQnNl2j7Z6jDUzfq1GYFPYPuEwZ9C7HMKMwXmTzM-hKrE9mcnQe40IogCw3mZ7IdHl151Fi5WLJ5T4GXEKuwDqxzLLw&usqp=CAc",
      colors: ["Black", "Red", "Pink"],
    },
    {
      title: "Blanket",
      price: 30,
      description:
        "15-pound, quilted weighted blanket designed to reduce stress and improve sleep",
      image:
        "https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcSLTNQBi7zghqgU5TX6FihhA4j5pPJbJgMPddk6erB2xNdKFrAVtW-1IQsbgJwrjOWlSaf031YvCElBROCcbg1dpKITUV2Sb02IweborrK_bmgbhbNq43KgjuxzAWe7dLfOjt3pvj5aBO8&usqp=CAc",
      colors: ["Black", "Brown", "Blue"],
    },
  ];

  // Map over the items array to display each product card
  const itemsLists = items.map((item) => {
    // Get the selected color 
    const selectedColor = selectedColors[item.title] || "Dropdown button";

      // Return Product card 
    return (
      <Card style={{ width: "18rem", margin: "1rem" }} key={item.title}>
        <Card.Img variant="top" src={item.image} />
        <Card.Body>
          <Card.Title>{item.title}</Card.Title>
          <Card.Text>${item.price}</Card.Text>
          <Card.Text>{item.description}</Card.Text>

{/* Dropdown for color selection */}
          <Dropdown className="mb-2">
            <Dropdown.Toggle
              variant="secondary"
              id={`dropdown-${item.title}`}
              style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}
            >
              {/* Display the selected color, with a color dot if selected */}
              {selectedColor !== "Dropdown button" && (
                <span
                  style={{
                    width: "12px",
                    height: "12px",
                    borderRadius: "50%",
                    backgroundColor: selectedColor.toLowerCase(),
                    border: "1px solid #ccc",
                  }}
                ></span>
              )}
              {selectedColor}
            </Dropdown.Toggle>

    {/* Dropdown menu to select colors */}
            <Dropdown.Menu>
              {item.colors.map((color, index) => (
                <Dropdown.Item
                  key={index}
                  onClick={() => handleColorSelect(item.title, color)}
                >
                  {color}
                </Dropdown.Item>
              ))}
            </Dropdown.Menu>
          </Dropdown>

       {/* Buy button to add product price to total */}
          <Button onClick={() => handleBuy(item.price)}>Buy</Button>
        </Card.Body>
      </Card>
    );
  });

  return (
    <div>
         {/* Show welcome message after login*/}
      {name ? (
        <>
          <h2>Welcome back, {name}</h2>
          <button onClick={() => navigate("/")}>Logout</button>
          <h1 className="section">Our Products</h1>

          {/* Display the product cards */}
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
            }}
          >
            {itemsLists}
          </div>
        </>
      ) : (
        <h2>Please login first to see this page.</h2> 
      )}
    </div>
  );
}
