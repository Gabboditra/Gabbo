import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";

// Home component handles login functionality
export default function Home() {
  const [name, setName] = useState(""); // State to store user's name
  const [isLoggedIn, setIsLoggedIn] = useState(false); // State to manage login status
  const inputRef = useRef(null); // ref to access the input element
  const navigate = useNavigate(); // React Router hook for navigation

   // Focus on the input when user is not logged in
  useEffect(() => {
    if (!isLoggedIn) inputRef.current?.focus();
  }, [isLoggedIn]);

   // Handles login logic
  const handleLogin = () => {
    if (name.trim()) {
      setIsLoggedIn(true);
      navigate("/Products", { state: { name } });
    } else {
      alert("Please enter a name");
    }
  };

   // Handles logout logic
  const handleLogout = () => {
    setName("");
    setIsLoggedIn(false);
  };

  return (
    <div className="tab-content">
      {!isLoggedIn ? (
        <>
            {/* Input field for user to enter their name */}
          <input
            type="text"
            placeholder="Enter your name"
            className="form-control"
            onChange={(e) => setName(e.target.value)}
            value={name}
            ref={inputRef}
          />
          <button className="btn btn-primary mt-2" onClick={handleLogin}>
            Login
          </button>
        </>
      ) : (
        <>
         {/* Greeting and logout button if user is logged in */}
          <h1>Welcome, {name}</h1>
          <button className="btn btn-secondary mt-2" onClick={handleLogout}>
            Logout
          </button>
        </>
      )}
    </div>
  );
}
