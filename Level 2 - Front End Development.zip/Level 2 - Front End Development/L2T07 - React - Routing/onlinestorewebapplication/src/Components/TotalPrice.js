import React from "react";

// Component to display the total price of products 
export default function TotalPrice({ sum }) {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">Total price:</h2>
      <p className="mt-4 font-semibold">Total: ${sum}</p>
    </div>
  );
}
