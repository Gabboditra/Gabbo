import "./App.css";
import React from "react";
import AutoFocusInput from "./Components/AutoFocusInput";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  <AutoFocusInput />;

  return (
    <div className="App">
      <h1> Predict the Ethnicity of a Name </h1>
      <AutoFocusInput />
    </div>
  );
}

export default App;
