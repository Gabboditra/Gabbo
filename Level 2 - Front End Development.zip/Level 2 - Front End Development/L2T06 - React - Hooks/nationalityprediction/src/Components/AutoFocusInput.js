import { useState, useRef, useEffect } from "react";

function AutoFocusInput() {
  // useState is a hook that keeps track of the state in a functional component, in this case inputValue.
  const [inputValue, setInputValue] = useState("");

  // useRef is a hook that gets a reference to a DOM element, in this case the input element.
  const inputRef = useRef(null);

  // useEffect is a hook that runs a side effect after the component has rendered, in this case focusing the input element.
  useEffect(() => {
    inputRef.current.focus();
  }, []);

  // this function is called when the button is clicked.
  async function fetchData() {
    // It fetches data from the API using the inputValue as a parameter.
    const response = await fetch(
      `https://api.nationalize.io?name=${inputValue}`
    ); // Fetch data from the API using the fetch function.

    // Parse the JSON response from the API.
    let data = await response.json();

    // get the first result from the API response.
    const firstCountry = data.country[0]; // Get the first country from the response.

    // Check if the first country has the required properties.
    if (firstCountry && firstCountry.country_id && firstCountry.probability) {
      // log the results to the console.
      console.log(firstCountry.country_id);
      console.log(firstCountry.probability);

      // Update the input field to show the country and probability
      setInputValue(`${firstCountry.country_id} - ${firstCountry.probability}`);
    }
  }

  // render the input field and button, a paragraph showing the current value, and a button to fetch data
  return (
    <div>
      <input
        ref={inputRef}
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
      />
      <p>Input Value: {inputValue}</p>
      <button onClick={() => fetchData()}>Fetch Data</button>
    </div>
  );
}

export default AutoFocusInput;
