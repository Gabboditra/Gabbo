import "./App.css";
import { useState, useEffect, useRef } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

/*function to create a weather app*/

function App() {
  /*useState to manage state*/

  const [weather, setWeather] = useState("");
  const [city, setCity] = useState("");

  /*inputRef to manage input focus*/

  const inputRef = useRef(null);

  /*useEffect to focus on input field when component mounts*/

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  /*function to fetch weather data from API*/

  async function fetchData() {
    if (!city.trim()) {
      setWeather("Please enter a city name.");
      return;
    }

    /*API key for weather API*/

    const apiKey = process.env.REACT_APP_WEATHER_API_KEY;
    try {
      /*fetching data from weather API*/

      const response = await fetch(
        `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city}`
      );

      /*error handling*/

      if (!response.ok) {
        throw new Error("City not found or bad request");
      }

      /*parsing the response*/

      const data = await response.json();
      const location = data.location;
      const currentWeather = data.current;

      /*checking if location and currentWeather are available*/

      if (location && currentWeather) {
        /*logging the location name and current temperature*/

        console.log(location.name);
        console.log(currentWeather.temp_c);

        /*setting the weather state*/

        setWeather(`in ${location.name}: ${currentWeather.temp_c}°`);
      }
    } catch (error) {
      // Handling errors
      console.error("Error fetching weather data:", error.message);
      setWeather("Error: Could not fetch weather data.");
    }
  }

  /*function to handle input change*/

  return (
    <div>
      <input
        ref={inputRef}
        type="text"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />

      {/*button to fetch weather data*/}
      <p>
        {" "}
        Location: {city} | Current Weather {weather}{" "}
      </p>
      <button onClick={fetchData}>Fetch Weather's Data</button>
    </div>
  );
}

export default App;
