{
  /*importing necessary modules and components*/
}
import React from "react";
import "./Dashboard.css";
import HyperionDevLogo from "../assets/HyperionDevLogo.png";
import Welcome from "./Welcome.js";
import "bootstrap-icons/font/bootstrap-icons.css";

{
  /*Dashboard component to display the main dashboard layout*/
}
function Dashboard() {
  {
    /* defining a constant variable for the user name*/
  }
  const UserName = "Gabriele Di Trapani";
  return (
    <div className="page-container">
      {/* Left Sidebar Section */}
      <div className="left-column">
        <div className="sidebar">
          <img src={HyperionDevLogo} alt="HyperionDev Logo" />

          {/* Navigation Menu */}
          <ul className="nav flex-column">
            <li className="nav-item mb-2">
              <div className="nav-link active">
                <i className="bi bi-speedometer2 me-2"></i> Dashboard{" "}
              </div>
            </li>
            <li className="nav-item mb-2">
              <div className="nav-link">
                <i className="bi bi-person-circle me-2"></i> Profile
              </div>
            </li>
            <li className="nav-item mb-2">
              <div className="nav-link">
                {" "}
                <i className="bi bi-lightning-charge me-2"></i>"Learning
                Accelerator
              </div>
            </li>
            <li className="nav-item mb-2">
              <div className="nav-link">
                <i className="bi bi-info-circle me-2"></i> Navigating your
                Dashboard
              </div>
            </li>
            <li className="nav-item mb-2">
              <div className="nav-link">
                <i className="bi bi-share me-2"></i> Share Portfolio
              </div>
            </li>
            <li className="nav-item mb-2">
              <div className="nav-link">
                <i className="bi bi-box-arrow-right me-2"></i> Sign out
              </div>
            </li>
          </ul>

          {/* Support Info */}
          <div className="nav-link">
            <strong>Your support will expire on:</strong>
            <br />
            05 September 2025
          </div>

          {/* Submit Query Box */}
          <div className="row mt-4">
            <div className="col">
              <div className="left-box">Submit a query</div>
            </div>
          </div>
        </div>
      </div>

      {/* Center Content Section */}
      <div className="center-column">
        {/* Tech Talks Section */}
        <div className="center-box1">
          <h6>Tech Talks</h6>
          <br />
          <p>
            In our Tech Talks live sessions, students participate in discussions
            on a range of topics within software engineering, data science,
            cybersecurity, full stack development, and more. Each session covers
            recent industry trends and practical applications relevant to these
            fields. Through instructor demonstrations, practical examples, and
            Q&A, students can deepen their understanding and learn ways to
            approach real-world challenges. These sessions help bridge theory
            with practice, supporting the skills they are developing in their
            bootcamp.
            <br />
            <br />
            Session Time: Tuesday at 6pm SAST
            <br /> <br />
            To register, please click on the link below:
            <br />
            <a
              href="https://livesessions.hyperiondev.com/hyperionedevacademic.html"
              target="_blank"
              rel="noopener noreferrer"
            >
              https://livesessions.hyperiondev.com/hyperionedevacademic.html
            </a>
          </p>
        </div>

        {/* Welcome and Student Info Section */}
        <div className="center-box2">
          <Welcome name={UserName} />
          <div className="info-row">
            <p className="info-text">
              You’re doing a fantastic job and are in line with our enrolment
              policy!
            </p>
            <div className="vertical-divider"></div>
            <p className="info-text">100% AVG. GRADE</p>
            <div className="vertical-divider"></div>
            <p className="info-text">
              You’re on track! See our Student Handbook for more information on
              progression.
            </p>
          </div>
        </div>

        {/* Link to the Website */}
        <div className="center-box3">
          <br />
          <p>Link to Website: </p>
          <a
            href="https://www.hyperiondev.com/portal/"
            target="_blank"
            rel="noopener noreferrer"
          >
            https://www.hyperiondev.com/portal/
          </a>
        </div>
      </div>

      {/* Right Sidebar Section */}
      <div className="right-column">
        <div className="sidebar">
          <ul className="bullet-list">
            {/* User Info */}
            <li>
              <strong>{UserName}</strong>
            </li>
            <li>
              <strong>GD25010016724</strong>
            </li>
            <li>
              <strong>The University of Manchester Web Development</strong>
            </li>
            <br />
            <br />

            {/*additional links and info */}
            <p>
              <i className="bi bi-gift me-2"></i> Refer a friend and earn €250
            </p>
            <p>
              <i className="bi bi-github me-2"></i> Go to GitHub
            </p>
            <p>
              <i className="bi bi-chat-dots me-2"></i> Go to Discourse
            </p>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
