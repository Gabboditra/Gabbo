import React from "react";

 {/* display the Welcome message*/}
function Welcome({ name }) {
  return (
    <div>
      <h5> Welcome back {name} </h5>
    </div>
  );
}
export default Welcome;
