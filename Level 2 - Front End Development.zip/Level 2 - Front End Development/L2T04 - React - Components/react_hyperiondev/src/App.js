import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Dashboard from "./components/Dashboard.js";

function App() {
  return (
    <div className="App">
      <hr />
      {/* display the Dashboard component */}
      <Dashboard />
      <hr />
    </div>
  );
}

export default App;
