import { Routes, Route, Link } from "react-router-dom";
import Home from "./Components/Home";
import Products from "./Components/Products";
import "bootstrap/dist/css/bootstrap.min.css";
import About from "./Components/About";
import React from 'react';
import LoginForm from "./Components/LoginPage";
import RegistrationForm from "./Components/RegistrationPage";

export default function App() {
  return (
    <div className="App">
        <h1>Online Store Web Application</h1>

      <nav>
        <Link to="/">Home</Link>
        <br />
        <Link to="/Products">Products</Link>
        <br />
        <Link to="/About">About</Link>
        <br />
        <Link to="/LoginPage"> Login Page </Link>
        <br />
        <Link to="/RegistrationPage"> Registration Page </Link>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Products" element={<Products />} />
        <Route path="/About" element={<About />} />
        <Route path="/LoginPage" element={<LoginForm />} />
        <Route path="/RegistrationPage" element={<RegistrationForm />} />
      </Routes>
    </div>
  );
}
