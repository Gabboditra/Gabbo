import React from "react";
import { useFormik } from "formik";

// validate function
const validate = (values) => {
  const errors = {};

  const registrationFields = [
    { field: "firstName", label: "First name", maxLength: 15, alphaOnly: true },
    { field: "surname", label: "Surname", maxLength: 20, alphaOnly: true },
    { field: "email", label: "Email" },
    { field: "password", label: "Password", minLength: 8 },
    { field: "confirmPassword", label: "Confirm password" },
  ];

  registrationFields.forEach(
    ({ field, label, maxLength, minLength, alphaOnly }) => {
      const value = values[field];

      // check if the value exists
      if (!value) {
        errors[field] = "Required";
      }

      // Max length validation
      if (maxLength && value.length > maxLength) {
        errors[field] = `${label} must be ${maxLength} characters or less`;
      }

      // Min length validation
      if (minLength && value.length < minLength) {
        errors[field] = `${label} must be ${minLength} characters or more`;
      }

      // Alpha-only validation
      if (alphaOnly && !/^[a-zA-Z\s]+$/.test(value)) {
        errors[field] = `Invalid ${label.toLowerCase()} (letters only)`;
      }

      // Email validation
      if (
        field === "email" &&
        !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(value)
      ) {
        errors[field] = "Invalid email address";
      }

      // Password validation
      if (
        field === "password" &&
        !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?#&])[A-Za-z\d@$!%*?#&]{8,}$/.test(
          value
        )
      ) {
        errors[field] =
          "Password must include uppercase, lowercase, number, and special character";
      }

      // Confirm Password validation
      if (field === "confirmPassword" && value !== values.password) {
        errors[field] = "Passwords do not match";
      }
    }
  );

  return errors;
};

const RegistrationForm = () => {
  const formik = useFormik({
    initialValues: {
      firstName: "",
      surname: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
    validate, // Custom validation function
    onSubmit: (values) => {
      alert(JSON.stringify(values, null, 2));
    },
  });

  return (
    <form onSubmit={formik.handleSubmit}>
      <label htmlFor="firstName">First Name</label>
      <input
        id="firstName"
        name="firstName"
        type="text"
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        value={formik.values.firstName}
      />
      {formik.touched.firstName && formik.errors.firstName ? (
        <div>{formik.errors.firstName}</div>
      ) : null}

      <label htmlFor="surname">Surname</label>
      <input
        id="surname"
        name="surname"
        type="text"
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        value={formik.values.surname}
      />
      {formik.touched.surname && formik.errors.surname ? (
        <div>{formik.errors.surname}</div>
      ) : null}

      <label htmlFor="email">Email Address</label>
      <input
        id="email"
        name="email"
        type="email"
        onChange={formik.handleChange}
        value={formik.values.email}
      />
      {formik.touched.email && formik.errors.email ? (
        <div>{formik.errors.email}</div>
      ) : null}

      <label htmlFor="password">Password</label>
      <input
        id="password"
        name="password"
        type="password"
        onChange={formik.handleChange}
        value={formik.values.password}
      />
      {formik.touched.password && formik.errors.password ? (
        <div>{formik.errors.password}</div>
      ) : null}

      <label htmlFor="confirmPassword">Confirm Password</label>
      <input
        id="confirmPassword"
        name="confirmPassword"
        type="password"
        onChange={formik.handleChange}
        value={formik.values.confirmPassword}
      />
      {formik.touched.confirmPassword && formik.errors.confirmPassword ? (
        <div>{formik.errors.confirmPassword}</div>
      ) : null}

      <button type="submit">Submit</button>
    </form>
  );
};

export default RegistrationForm;
