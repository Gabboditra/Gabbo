import React from "react";
import { useNavigate } from "react-router-dom";
import { useState, useRef, useEffect } from "react";

export default function Home() {
  const navigate = useNavigate();
  const [name, setName ] = useState("");

  const inputRef = useRef(null);
  useEffect(() => {
    inputRef.current.focus();
  }, []);

  return (
    <div className="tab-content"> 
       <input 
       type="text"
       placeholder="enter your name"
       className="form-control"
       onChange={(e) => setName(e.target.value) }
       value={name}
       ref={inputRef}
        />	 
        <button className="btn btn-primary mt-2" onClick={() => 
          {if (name.trim()) { navigate("/Products", { state: { name } });
        } else {alert("Please enter a name");
        } 
        }} 
        
        >Login</button>   
    </div>
  );
}
