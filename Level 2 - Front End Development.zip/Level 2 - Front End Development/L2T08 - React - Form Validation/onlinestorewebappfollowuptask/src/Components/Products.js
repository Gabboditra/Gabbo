import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

export default function Products() {
  const location = useLocation();
  const state = location.state;
  const navigate = useNavigate();
  const name = state?.name;

  return (
    <div>
      {name ? (
        <>
          {" "}
          <h2>Welcome back, {name}</h2>
          <button onClick={() => navigate("/")}> Logout </button>
        </>
      ) : (
        <h2>Please login first to see this page.</h2>
      )}
    </div>
  );
}
