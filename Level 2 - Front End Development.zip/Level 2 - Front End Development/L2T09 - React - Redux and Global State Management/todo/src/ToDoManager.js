import { configureStore, createSlice } from '@reduxjs/toolkit';

// Create a "slice" of the Redux store to manage to-do tasks
const todoSlice = createSlice({
  name: 'todo', 
  initialState: {
    heading: 'To-do App',
    list: [
      { id: 1, task: 'Shopping', completed: false },
      { id: 2, task: 'Swimming', completed: false }
    ]
  },

// Define Reducers (actions that change state)
  reducers: {
    // Adds a new task to the list
    add: (state, action) => {
      state.list.push(action.payload);
    },
    // edits an existing task by id
    edit: (state, action) => {
      const item = state.list.find((t) => t.id === action.payload.id);
      if (item && !item.completed) {
        item.task = action.payload.task;
      }
    },
     // Removes a task by id
    removeTask: (state, action) => {
      state.list = state.list.filter((t) => t.id !== action.payload.id);
    },
        // Marks a task as completed by id
    completed: (state, action) => {
      const item = state.list.find((t) => t.id === action.payload.id);
      if (item) {
        item.completed = true;
      }
    }
  }
});

// Exporting actions to use in components
export const { add, edit, removeTask, completed } = todoSlice.actions;

// Creating the Redux store and registering the slice reducer
const store = configureStore({
  reducer: {
    todo: todoSlice.reducer 
  }
});

export default store;
