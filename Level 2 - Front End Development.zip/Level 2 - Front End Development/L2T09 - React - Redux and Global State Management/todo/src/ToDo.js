import React, { useState } from "react";
import { Form, Button } from "react-bootstrap";
import { useSelector, useDispatch } from "react-redux";
import { add, edit, removeTask, completed } from "./ToDoManager";
import "./App.css";

export default function Counter() {
  // gets the task list from the Redux store
  const todoList = useSelector((state) => state.todo.list);
  // sends actions (like add/edit) to the store
  const dispatch = useDispatch();

  // State hooks for form input and UI control
  const [task, setTask] = useState(""); // Current task input
  const [editing, setEditing] = useState(null); // task id being edited
  const [showInfo, setShowInfo] = useState(false); // Toggle for info modal

  // Adds or updates a task
  const handleSubmit = () => {
    if (!task.trim()) return; // Ignore empty input

    if (editing) {
      dispatch(edit({ id: editing, task })); // Update task
    } else {
      dispatch(add({ id: Date.now(), task, completed: false })); // Add new task
    }

    // Reset form
    setTask("");
    setEditing(null);
  };

  return (
    <div className="app-container">
      {/* Header with title, info icon, and task counter */}
      <header className="fixed-header">
        <h2>To-do App</h2>
        <Button variant="link" onClick={() => setShowInfo(true)}>
          ℹ️
        </Button>
        <div className="counter">Total: {todoList.length}</div>
      </header>

      {/* Input area for new tasks */}
      <div className="input-section">
        <Form.Control
          type="text"
          value={task}
          onChange={(e) => setTask(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
          placeholder="Enter task"
        />
        <Button className="mt-2" onClick={handleSubmit}>
          {editing ? "Update" : "Add"}
        </Button>
      </div>

      {/* Render the list of tasks */}
      <ul className="todo-list">
        {todoList.map(({ id, task: t, completed: done }) => (
          <li key={id} className={done ? "completed-task" : ""}>
            {t}
            <div className="btn-group">
              <Button
                size="sm"
                disabled={done}
                onClick={() => {
                  setTask(t);
                  setEditing(id);
                }}
              >
                Edit
              </Button>
              <Button
                size="sm"
                variant="danger"
                onClick={() => dispatch(removeTask({ id }))}
              >
                Delete
              </Button>
              <Form.Check
                type="checkbox"
                checked={done}
                onChange={() => dispatch(completed({ id }))}
                label="Done"
              />
            </div>
          </li>
        ))}
      </ul>

      {/* Info Modal */}
      {showInfo && (
        <div className="info-popup">
          <div className="info-content">
            <p>Add, edit, delete, and complete your tasks here.</p>
            <Button onClick={() => setShowInfo(false)}>Close</Button>
          </div>
        </div>
      )}
    </div>
  );
}
