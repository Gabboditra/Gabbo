import React from 'react';
import Counter from './ToDo';


function App() {
  return (
    <div>
      <header className="App-header">
        <h2> To-do app </h2>
        <Counter />
      </header>
    </div>
  );
}

export default App;
