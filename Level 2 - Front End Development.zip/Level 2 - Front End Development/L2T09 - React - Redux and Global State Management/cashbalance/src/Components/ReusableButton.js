import React from 'react';
import { Button } from 'react-bootstrap'; // If using React Bootstrap

// component which allows to reuse the same button style for all actions without duplicating code
function ReusableButton({ label, onClick }) {
  return (
    <Button onClick={onClick} variant="primary" className="m-2">
      {label}
    </Button>
  );
}

export default ReusableButton;
