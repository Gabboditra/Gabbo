import React, { useState, useContext } from 'react';
import { GlobalContext, GlobalStateProvider } from './GlobalState';  
import ReusableButton from './Components/ReusableButton';

function App() {
  const [amount, setAmount] = useState(0);
  const { balance, dispatch } = useContext(GlobalContext);

  const deposit = (amount) => {
    dispatch({ type: 'DEPOSIT', payload: amount });
  };

  const withdraw = (amount) => {
    dispatch({ type: 'WITHDRAW', payload: amount });
  };
  const addInterest = () => {
    dispatch({ type: 'ADD_INTEREST' });
  };

  // Function to apply charges
  const applyCharges = () => {
    dispatch({ type: 'CHARGES' });
  };

  return (
    <GlobalStateProvider>
      <div className="App">
        <h1 className="App-header">Account Balance App</h1>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(Number(e.target.value))}
          placeholder="Enter amount"
        />
        <div>
          <ReusableButton label="Deposit" onClick={() => deposit(amount)} />
          <ReusableButton label="Withdraw" onClick={() => withdraw(amount)} />
          <ReusableButton label="Add Interest" onClick={() => addInterest()} />
          <ReusableButton label="Charges" onClick={() => applyCharges()} />
        </div>
        <div>
          <p>Current Balance: ${balance}</p>
        </div>
      </div>
    </GlobalStateProvider>
  );
}

export default App;
