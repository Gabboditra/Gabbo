import React, { createContext, useReducer } from "react";

// This is where the balance state is stored and shared throughout the app
export const GlobalContext = createContext();

// Initial state
export const initialState = {
  balance: 0,
};

// Reducer function to manage a global state (balance in this case)
export const globalStateReducer = (state, action) => {
  switch (action.type) {
    case "DEPOSIT":
      return { ...state, balance: state.balance + action.payload };
    case "WITHDRAW":
      return { ...state, balance: state.balance - action.payload };
    case "ADD_INTEREST":
      return { ...state, balance: state.balance * 1.05 };
    case "CHARGES":
      return { ...state, balance: state.balance * 0.85 };
    default:
      return state;
  }
};

// GlobalStateProvider wraps the app and provides the balance state and a method (dispatch) for modifying the state using the useReducer hook.
export const GlobalStateProvider = ({ children }) => {
  const [state, dispatch] = useReducer(globalStateReducer, initialState);

  return (
    <GlobalContext.Provider value={{ balance: state.balance, dispatch }}>
      {children}
    </GlobalContext.Provider>
  );
};