import { render } from '@testing-library/react';  // Import from React Testing Library
import Greetings from './Greetings';
import React from 'react';  // Add this line

test('Greetings renders correctly', () => {
  const { container } = render(<Greetings />);
  expect(container).toMatchSnapshot();  // Use the container to match snapshot
});
