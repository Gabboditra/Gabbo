import React from "react";

 function Greetings() {

 return (
 <div>
 <p> Hello, World! </p>
 </div>
 );
 }
 export default Greetings;