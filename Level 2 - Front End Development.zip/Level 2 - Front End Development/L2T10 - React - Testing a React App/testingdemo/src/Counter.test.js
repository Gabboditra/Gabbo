import { render, fireEvent } from '@testing-library/react';
 import App from './App';
 import React from 'react';  // Import React
 import '@testing-library/jest-dom';


 test('increments the count', () => {
 const { getByText } = render(<App />);
 const incrementButton = getByText('Increment');
 fireEvent.click(incrementButton);
 expect(getByText('Count: 1')).toBeInTheDocument();
 })

 test('decrements the count', () => {
    const { getByText } = render(<App />);
    const decrementButton = getByText('Decrement');
    fireEvent.click(decrementButton);
    expect(getByText('Count: -1')).toBeInTheDocument();
  });