import React, { useState } from "react";

{
  /* This component allows the user to deposit money and add interest to their balance.*/
}
export default function DepositMoney({ balance, setBalance }) {
  const [deposit, setDeposit] = useState(0);

  function increaseBalance() {
    balance = balance + Number(deposit);
    setBalance(parseFloat(balance.toFixed(2)));
  }

  function addInterest() {
    const interest = balance * 0.1;
    {
      /* Calculate interest*/
    }
    setBalance(parseFloat((balance + interest).toFixed(2)));
    {
      /*Add 10% interest*/
    }

    {
      /*This button adds the deposit amount to the current balance*/
    }
    return (
      <div>
        <input
          onChange={(event) => setDeposit(event.target.value)}
          id="DepositMoney"
          type="number"
          placeholder="enter amount"
        />
        <button onClick={increaseBalance}>Add deposit</button>
        {/* This button adds interest to the current balance. */}
        <input
          onChange={(event) => setDeposit(event.target.value)}
          id="DepositMoney"
          type="number"
          placeholder="enter amount"
        />
        <button onClick={addInterest}>Add interest</button>
      </div>
    );
  }
}
