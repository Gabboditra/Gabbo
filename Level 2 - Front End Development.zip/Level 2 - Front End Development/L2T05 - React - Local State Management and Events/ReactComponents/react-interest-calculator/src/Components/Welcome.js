import React from "react";

{/*this component displays the Welcome message*/}
function Welcome({ name }) {
  return (
    <div>
      <h1> Welcome back {name} </h1>
    </div>
  );
}
export default Welcome;
