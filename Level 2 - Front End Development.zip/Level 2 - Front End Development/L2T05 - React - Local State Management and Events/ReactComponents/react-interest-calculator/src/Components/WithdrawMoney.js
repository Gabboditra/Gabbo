import React, { useState } from "react";

{
  /*this component allows the user to withdraw money and deduct bank fees from their balance.*/
}

export default function WithdrawMoney({ balance, setBalance }) {
  const [withdraw, setWithdraw] = useState(0);

  function decreaseBalance() {
    balance = balance - Number(withdraw);
    setBalance(parseFloat(balance.toFixed(2)));
  }

  function addBankFees() {
    const bankFees = balance * 0.01;
    {
      /*Calculate bank fees*/
    }
    setBalance(parseFloat((balance - bankFees).toFixed(2)));
    {
      /*Add 1% interest*/
    }
  }

  {
    /*this button deducts the withdraw amount from the current balance.*/
  }
  return (
    <div>
      {/* Only update Withdraw value */}
      <input
        onChange={(event) => setWithdraw(event.target.value)}
        id="WithdrawMoney"
        type="number"
        placeholder="enter amount"
      />
      <button onClick={decreaseBalance}>Withdraw money </button>

      {/* this button deducts the bank fees from the current balance.*/}
      <input
        onChange={(event) => setWithdraw(event.target.value)}
        id="WithdrawMoney"
        type="number"
        placeholder="enter amount"
      />
      <button onClick={addBankFees}>Deduct bank fees </button>
    </div>
  );
}
