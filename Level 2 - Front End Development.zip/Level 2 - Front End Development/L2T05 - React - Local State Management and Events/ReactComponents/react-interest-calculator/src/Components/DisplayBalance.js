import React from "react";

{/*this component displays the current balance of the user*/}

export default function DisplayBalance({ balance }) {
  return (
    <div>
      <h3>Current Balance: ${balance}</h3>
    </div>
  );
}
