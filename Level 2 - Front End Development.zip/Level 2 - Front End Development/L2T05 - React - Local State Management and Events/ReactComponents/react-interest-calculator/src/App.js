
  {/*Import files and components*/}

import "./App.css";
import Welcome from "./Components/Welcome";
import DepositMoney from "./Components/DepositMoney";
import WithdrawMoney from "./Components/WithdrawMoney";
import DisplayBalance from "./Components/DisplayBalance";
import React, { useState } from "react";

function App() {
  const [balance, setBalance] = useState(1000);
  return (
    <div className="App">
      <hr />

      <Welcome name="Gabriele" />

      <DisplayBalance balance={balance} />
      <WithdrawMoney balance={balance} setBalance={setBalance} />
      <DepositMoney balance={balance} setBalance={setBalance} />
    </div>
  );
}
export default App;
